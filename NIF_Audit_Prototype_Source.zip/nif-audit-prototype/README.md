# NIF audit management prototype

This is an interactive design simulation, not a connection to NIF or APICenter.
All routes, partners, requests and cluster results are fictional. Browser-local
storage retains your simulation in that browser; Reset demo restores the seed.

Open the hosted prototype for the easiest access. To run this package locally,
serve `dist` with any static HTTP server, for example:

```bash
python3 -m http.server 8080 --directory dist
```

Then visit http://localhost:8080. Opening index.html directly through `file://`
can prevent browsers from loading JavaScript modules. No npm installation,
external fonts, CDN assets or application backend is needed.

## Suggested walkthrough

1. Open Loan application intake. Its desired policy is disabled at v2, but
   nif-03 still runs enabled v1; the route is partially applied.
2. Start an exchange on that route using nif-03. Leave it in flight.
3. Open NIF instances. Uncheck Block updates for nif-03, then reconcile.
4. Return to Route policies and finish the exchange. It keeps its pinned
   enabled v1 decision. A new exchange on nif-03 uses disabled v2.
5. Check Authorization denied and start/finish another exchange. Ordinary
   transaction capture is skipped but the independent security event appears.
6. Change a route policy. Notice the unsaved draft; review/save with a reason,
   then simulate propagation to install the desired version.
7. Select several routes and bulk disable. A mandatory route is skipped with
   feedback while staging; its policy cannot be disabled. Internal routes are
   excluded. Review the resulting draft before committing it.
8. Inspect Change history, stage a rollback, and save it as a new version.
9. Switch to P2 outbound. Inspect destination mappings and the shared controls.

APIs loan.create and loan.status share one landing route; loan.create also maps
to Mobile loan landing. These are many-to-many registry associations, not new
source entitlements. Audit changes never alter operational route states.

## Checks

```bash
node test-model.mjs
node --check dist/app.js
```

The checks verify the simulation's policy and propagation model. They do not
test a real Camel adapter, authorization service, durable audit pipeline,
RBAC, immutable storage or production cluster membership.

The architecture document contains eight diagrams and the proposed production
schema, REST contracts, failure handling and roadmap. Mermaid diagrams render
in a compatible Markdown viewer.
